const express = require('express');
const { body, validationResult } = require('express-validator');
const { executeQuery } = require('../config/database');
const { authenticateToken } = require('./auth');
const router = express.Router();

// Get user's cart items
router.get('/', authenticateToken, async (req, res) => {
  try {
    const cartItems = await executeQuery(`
      SELECT 
        ci.id,
        ci.quantity,
        p.id as product_id,
        p.name,
        p.description,
        p.price,
        p.image_url,
        p.stock_quantity,
        (ci.quantity * p.price) as subtotal
      FROM cart_items ci
      JOIN products p ON ci.product_id = p.id
      WHERE ci.user_id = ? AND p.is_active = TRUE
      ORDER BY ci.created_at DESC
    `, [req.user.userId]);

    const total = cartItems.reduce((sum, item) => sum + parseFloat(item.subtotal), 0);

    res.json({
      items: cartItems,
      summary: {
        itemCount: cartItems.length,
        totalQuantity: cartItems.reduce((sum, item) => sum + item.quantity, 0),
        totalAmount: total.toFixed(2)
      }
    });

  } catch (error) {
    console.error('Cart fetch error:', error);
    res.status(500).json({ error: 'Failed to fetch cart' });
  }
});

// Add item to cart
router.post('/add', authenticateToken, [
  body('productId').isInt({ min: 1 }),
  body('quantity').isInt({ min: 1, max: 99 })
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { productId, quantity } = req.body;
    const userId = req.user.userId;

    // Check if product exists and is active
    const products = await executeQuery(
      'SELECT id, name, stock_quantity FROM products WHERE id = ? AND is_active = TRUE',
      [productId]
    );

    if (products.length === 0) {
      return res.status(404).json({ error: 'Product not found' });
    }

    const product = products[0];

    // Check stock availability
    if (quantity > product.stock_quantity) {
      return res.status(400).json({ 
        error: 'Insufficient stock',
        availableStock: product.stock_quantity
      });
    }

    // Check if item already exists in cart
    const existingItems = await executeQuery(
      'SELECT id, quantity FROM cart_items WHERE user_id = ? AND product_id = ?',
      [userId, productId]
    );

    if (existingItems.length > 0) {
      // Update existing item
      const newQuantity = existingItems[0].quantity + quantity;
      
      if (newQuantity > product.stock_quantity) {
        return res.status(400).json({ 
          error: 'Total quantity exceeds available stock',
          availableStock: product.stock_quantity,
          currentInCart: existingItems[0].quantity
        });
      }

      await executeQuery(
        'UPDATE cart_items SET quantity = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
        [newQuantity, existingItems[0].id]
      );

      res.json({ 
        message: 'Cart updated successfully',
        action: 'updated',
        newQuantity
      });
    } else {
      // Add new item
      await executeQuery(
        'INSERT INTO cart_items (user_id, product_id, quantity) VALUES (?, ?, ?)',
        [userId, productId, quantity]
      );

      res.status(201).json({ 
        message: 'Item added to cart successfully',
        action: 'added'
      });
    }

  } catch (error) {
    console.error('Add to cart error:', error);
    res.status(500).json({ error: 'Failed to add item to cart' });
  }
});

// Update cart item quantity
router.put('/update/:itemId', authenticateToken, [
  body('quantity').isInt({ min: 1, max: 99 })
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { itemId } = req.params;
    const { quantity } = req.body;
    const userId = req.user.userId;

    // Get cart item with product info
    const cartItems = await executeQuery(`
      SELECT ci.id, ci.product_id, p.stock_quantity, p.name
      FROM cart_items ci
      JOIN products p ON ci.product_id = p.id
      WHERE ci.id = ? AND ci.user_id = ? AND p.is_active = TRUE
    `, [itemId, userId]);

    if (cartItems.length === 0) {
      return res.status(404).json({ error: 'Cart item not found' });
    }

    const cartItem = cartItems[0];

    // Check stock availability
    if (quantity > cartItem.stock_quantity) {
      return res.status(400).json({ 
        error: 'Quantity exceeds available stock',
        availableStock: cartItem.stock_quantity
      });
    }

    // Update quantity
    await executeQuery(
      'UPDATE cart_items SET quantity = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
      [quantity, itemId]
    );

    res.json({ message: 'Cart item updated successfully' });

  } catch (error) {
    console.error('Cart update error:', error);
    res.status(500).json({ error: 'Failed to update cart item' });
  }
});

// Remove item from cart
router.delete('/remove/:itemId', authenticateToken, async (req, res) => {
  try {
    const { itemId } = req.params;
    const userId = req.user.userId;

    const result = await executeQuery(
      'DELETE FROM cart_items WHERE id = ? AND user_id = ?',
      [itemId, userId]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Cart item not found' });
    }

    res.json({ message: 'Item removed from cart successfully' });

  } catch (error) {
    console.error('Cart removal error:', error);
    res.status(500).json({ error: 'Failed to remove item from cart' });
  }
});

// Clear entire cart
router.delete('/clear', authenticateToken, async (req, res) => {
  try {
    const userId = req.user.userId;

    await executeQuery('DELETE FROM cart_items WHERE user_id = ?', [userId]);

    res.json({ message: 'Cart cleared successfully' });

  } catch (error) {
    console.error('Cart clear error:', error);
    res.status(500).json({ error: 'Failed to clear cart' });
  }
});

// Get cart item count (for header badge)
router.get('/count', authenticateToken, async (req, res) => {
  try {
    const result = await executeQuery(
      'SELECT COUNT(*) as count FROM cart_items WHERE user_id = ?',
      [req.user.userId]
    );

    res.json({ count: result[0].count });

  } catch (error) {
    console.error('Cart count error:', error);
    res.status(500).json({ error: 'Failed to get cart count' });
  }
});

module.exports = router;
