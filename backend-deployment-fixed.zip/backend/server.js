const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const compression = require('compression');
const slowDown = require('express-slow-down');
require('dotenv').config();

// Import logger
const logger = require('./config/logger');

// Import database initialization
const { runMigrations } = require('./database/migrate');
const { seedDatabase } = require('./database/seed');
const { testConnection } = require('./config/database');

const authRoutes = require('./routes/auth');
const productRoutes = require('./routes/products');
const cartRoutes = require('./routes/cart');
const orderRoutes = require('./routes/orders');
const healthRoutes = require('./routes/health');

const app = express();
const PORT = process.env.PORT || 3000;

// Database initialization function
async function initializeDatabase() {
  logger.info('🔄 Initializing database...');
  
  try {
    // Test database connection
    const connected = await testConnection();
    if (!connected) {
      throw new Error('Cannot connect to database');
    }
    
    // Run migrations (creates tables if they don't exist)
    await runMigrations();
    logger.info('✅ Database migrations completed');
    
    // Check if we need to seed data (only if products table is empty)
    const { executeQuery } = require('./config/database');
    const result = await executeQuery('SELECT COUNT(*) as count FROM products');
    
    if (result[0].count === 0) {
      logger.info('🌱 Database is empty, seeding initial data...');
      await seedDatabase();
      logger.info('✅ Database seeding completed');
    } else {
      logger.info('📊 Database already contains data, skipping seed');
    }
    
    return true;
  } catch (error) {
    logger.error('❌ Database initialization failed:', error);
    
    // In production, you might want to exit the process
    if (process.env.NODE_ENV === 'production' && process.env.REQUIRE_DB === 'true') {
      logger.error('🚨 Database required for production, exiting...');
      process.exit(1);
    }
    
    return false;
  }
}

// Trust proxy for ALB
app.set('trust proxy', 1);

// Compression middleware
app.use(compression());

// Request ID and logging middleware
app.use(logger.addRequestId);
app.use(logger.logRequest);

// Security middleware
app.use(helmet({
  crossOriginEmbedderPolicy: false,
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      scriptSrc: ["'self'"],
      imgSrc: ["'self'", "data:", "https:"],
    },
  },
}));

// Rate limiting - optimized for ALB
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: process.env.NODE_ENV === 'production' ? 1000 : 100,
  message: {
    error: 'Too many requests from this IP, please try again later.',
    retryAfter: '15 minutes'
  },
  standardHeaders: true,
  legacyHeaders: false,
  skip: (req) => {
    // Skip rate limiting for health checks and ALB
    return req.path === '/health' || 
           req.path === '/api/health' ||
           req.get('User-Agent')?.includes('ELB-HealthChecker');
  }
});

// Speed limiting for API routes
const speedLimiter = slowDown({
  windowMs: 15 * 60 * 1000, // 15 minutes
  delayAfter: 100, // allow 100 requests per 15 minutes at full speed
  delayMs: 500, // slow down subsequent requests by 500ms per request
  skip: (req) => {
    // Skip for health checks
    return req.path === '/health' || 
           req.path === '/api/health' ||
           req.get('User-Agent')?.includes('ELB-HealthChecker');
  }
});

app.use('/api/', limiter);
app.use('/api/', speedLimiter);

// CORS configuration for AWS deployment
const allowedOrigins = [
  // Local development
  'http://localhost:3000',
  'http://localhost:3001',
  
  // Environment variables for AWS deployment
  process.env.CLOUDFRONT_URL,
  process.env.S3_WEBSITE_URL,
  process.env.CUSTOM_DOMAIN,
  process.env.FRONTEND_URL,
  
  // Fallback patterns for AWS (will be replaced in deployment)
  'https://d1234567890123.cloudfront.net', // CloudFront pattern
  'https://ecommerce-frontend-*.s3-website-us-east-1.amazonaws.com', // S3 pattern
].filter(Boolean); // Remove undefined values

const corsOptions = {
  origin: function (origin, callback) {
    // Allow requests with no origin (like mobile apps, curl, ALB health checks)
    if (!origin) return callback(null, true);
    
    // Allow ELB health checker
    if (origin.includes('amazonaws.com')) {
      return callback(null, true);
    }
    
    // Check exact matches
    if (allowedOrigins.indexOf(origin) !== -1) {
      return callback(null, true);
    }
    
    // Check pattern matches for AWS domains
    const awsPatterns = [
      /^https:\/\/d[a-z0-9]+\.cloudfront\.net$/,
      /^https:\/\/ecommerce-frontend-[a-z0-9-]+\.s3-website-us-east-1\.amazonaws\.com$/,
      /^https:\/\/[a-z0-9-]+\.elb\.amazonaws\.com$/
    ];
    
    for (const pattern of awsPatterns) {
      if (pattern.test(origin)) {
        return callback(null, true);
      }
    }
    
    logger.warn('Blocked by CORS', { origin, userAgent: callback.req?.get('User-Agent') });
    callback(new Error('Not allowed by CORS'));
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: [
    'Origin',
    'X-Requested-With',
    'Content-Type',
    'Accept',
    'Authorization',
    'Cache-Control',
    'X-Forwarded-For',
    'X-Real-IP',
    'X-Request-ID'
  ],
  exposedHeaders: ['X-Total-Count', 'X-Request-ID'],
  optionsSuccessStatus: 200,
  maxAge: 86400 // 24 hours
};

app.use(cors(corsOptions));

// Handle preflight requests
app.options('*', cors(corsOptions));

// Body parsing middleware
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Health check endpoint (for AWS ALB) - must be before other routes
app.use('/health', healthRoutes);

// API routes
app.use('/api/auth', authRoutes);
app.use('/api/products', productRoutes);
app.use('/api/cart', cartRoutes);
app.use('/api/orders', orderRoutes);
app.use('/api/health', healthRoutes); // Add /api/health endpoint

// Root endpoint
app.get('/', (req, res) => {
  const response = {
    message: 'E-commerce API Server',
    version: '1.0.0',
    status: 'running',
    timestamp: new Date().toISOString(),
    environment: process.env.NODE_ENV || 'development',
    uptime: process.uptime(),
    requestId: req.requestId
  };
  
  logger.info('Root endpoint accessed', { 
    ip: req.ip, 
    userAgent: req.get('User-Agent'),
    requestId: req.requestId 
  });
  
  res.json(response);
});

// Error handling middleware
app.use((err, req, res, next) => {
  logger.error('Unhandled error', {
    error: err.message,
    stack: err.stack,
    url: req.originalUrl,
    method: req.method,
    ip: req.ip,
    userAgent: req.get('User-Agent'),
    requestId: req.requestId
  });
  
  res.status(500).json({
    error: 'Something went wrong!',
    message: process.env.NODE_ENV === 'development' ? err.message : 'Internal server error',
    requestId: req.requestId
  });
});

// 404 handler
app.use('*', (req, res) => {
  logger.warn('Route not found', {
    path: req.originalUrl,
    method: req.method,
    ip: req.ip,
    userAgent: req.get('User-Agent'),
    requestId: req.requestId
  });
  
  res.status(404).json({
    error: 'Route not found',
    path: req.originalUrl,
    requestId: req.requestId
  });
});

// Graceful shutdown
let server;

const gracefulShutdown = (signal) => {
  logger.info(`${signal} received, shutting down gracefully`);
  
  if (server) {
    server.close(() => {
      logger.info('HTTP server closed');
      process.exit(0);
    });
  } else {
    process.exit(0);
  }
  
  // Force close after 30 seconds
  setTimeout(() => {
    logger.error('Could not close connections in time, forcefully shutting down');
    process.exit(1);
  }, 30000);
};

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// Handle uncaught exceptions
process.on('uncaughtException', (err) => {
  logger.error('Uncaught Exception', { error: err.message, stack: err.stack });
  process.exit(1);
});

process.on('unhandledRejection', (reason, promise) => {
  logger.error('Unhandled Rejection', { reason, promise });
  process.exit(1);
});

// Start server with database initialization
async function startServer() {
  try {
    // Initialize database first
    const dbInitialized = await initializeDatabase();
    
    if (!dbInitialized && process.env.NODE_ENV === 'production' && process.env.REQUIRE_DB === 'true') {
      logger.error('🚨 Cannot start server without database in production mode');
      process.exit(1);
    }
    
    // Start the HTTP server
    server = app.listen(PORT, () => {
      logger.info(`🚀 E-commerce API server running on port ${PORT}`, {
        port: PORT,
        environment: process.env.NODE_ENV || 'development',
        nodeVersion: process.version,
        databaseInitialized: dbInitialized,
        timestamp: new Date().toISOString()
      });
      
      logger.info('📋 Server Status:', {
        cors: 'Configured for AWS deployment',
        security: 'Helmet, rate limiting enabled',
        compression: 'Enabled',
        healthCheck: `http://localhost:${PORT}/health`,
        apiEndpoint: `http://localhost:${PORT}/api`
      });
    });
    
    return server;
  } catch (error) {
    logger.error('❌ Failed to start server:', error);
    process.exit(1);
  }
}

// Start the server
startServer();
