module.exports = {
  apps: [
    {
      name: 'ecommerce-backend',
      script: 'server.js',
      instances: 'max',
      exec_mode: 'cluster',
      env: {
        NODE_ENV: 'production',
        PORT: 3000
      },
      autorestart: true,
      watch: false,
      max_memory_restart: '512M',
      out_file: '/opt/ecommerce-app/logs/pm2-out.log',
      error_file: '/opt/ecommerce-app/logs/pm2-error.log'
    }
  ]
};
