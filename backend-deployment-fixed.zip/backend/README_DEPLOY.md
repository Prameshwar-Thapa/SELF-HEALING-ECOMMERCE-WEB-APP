# E-commerce 3-Tier Deployment Quickstart

This package includes fixed deployment files for the backend and guidance for S3/CloudFront + ALB/ASG + RDS.

## Backend (EC2 behind ALB)
- Use **systemd** to run the Node/Express API.
- Provide environment variables in `/opt/ecommerce-app/backend/.env`.
- Health endpoints:
  - `/health` (deep: fails if DB is down)
  - `/live` (shallow: always 200, if your app exposes it)

### Files in `backend/`
- `ecommerce-backend.service` — production systemd unit
- `.env.production` — template; copy to `.env` and set real values
- `ecosystem.config.js` — optional PM2 file (not required if using systemd)
- `deploy-to-ec2.sh` — idempotent script to install deps and register the service
- `README_DEPLOY.md` — this file

### Suggested ALB Target Group Health Check
- Path: `/live` (or `/health` if you want deep checks)
- Healthy threshold: `2`
- Interval: `30s`
- Timeout: `5s`

## Frontend (S3 + CloudFront)
- Origin A: S3 (static site via OAC)
- Behavior (default): route to S3; cache static
- Behavior `/api/*`: route to ALB; **do not** cache; forward `Authorization`, cookies, query strings
- SPA routing: map 403/404 to `/index.html` with HTTP 200

## Database (RDS MySQL)
- Private subnets, security group only from backend SG on 3306
- DB user must have `CREATE/ALTER/INDEX` if the app runs migrations on startup
