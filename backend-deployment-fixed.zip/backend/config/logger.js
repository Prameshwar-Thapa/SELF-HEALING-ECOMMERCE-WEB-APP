const winston = require('winston');
const WinstonCloudWatch = require('winston-cloudwatch');

// Define log levels
const levels = {
  error: 0,
  warn: 1,
  info: 2,
  http: 3,
  debug: 4,
};

// Define colors for each level
const colors = {
  error: 'red',
  warn: 'yellow',
  info: 'green',
  http: 'magenta',
  debug: 'white',
};

// Add colors to winston
winston.addColors(colors);

// Define log format
const format = winston.format.combine(
  winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss:ms' }),
  winston.format.colorize({ all: true }),
  winston.format.printf(
    (info) => `${info.timestamp} ${info.level}: ${info.message}`,
  ),
);

// Define transports
const transports = [
  // Console transport for development
  new winston.transports.Console({
    format: winston.format.combine(
      winston.format.colorize(),
      winston.format.simple()
    )
  }),
  
  // File transports for production
  new winston.transports.File({
    filename: '/opt/ecommerce-app/logs/error.log',
    level: 'error',
    format: winston.format.combine(
      winston.format.timestamp(),
      winston.format.json()
    )
  }),
  
  new winston.transports.File({
    filename: '/opt/ecommerce-app/logs/combined.log',
    format: winston.format.combine(
      winston.format.timestamp(),
      winston.format.json()
    )
  }),
];

// Add CloudWatch transport for production
if (process.env.NODE_ENV === 'production' && process.env.AWS_REGION) {
  transports.push(
    new WinstonCloudWatch({
      logGroupName: `/aws/ec2/ecommerce-backend/${process.env.ENVIRONMENT || 'production'}`,
      logStreamName: `${process.env.INSTANCE_ID || 'unknown'}-${new Date().toISOString().split('T')[0]}`,
      awsRegion: process.env.AWS_REGION,
      messageFormatter: ({ level, message, additionalInfo }) => 
        `[${level}] : ${message} \nAdditional Info: ${JSON.stringify(additionalInfo, null, 2)}`
    })
  );
}

// Create logger instance
const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || (process.env.NODE_ENV === 'development' ? 'debug' : 'info'),
  levels,
  format,
  transports,
  exitOnError: false,
});

// Create a stream object for Morgan HTTP logging
logger.stream = {
  write: (message) => {
    logger.http(message.trim());
  },
};

// Add request ID tracking
logger.addRequestId = (req, res, next) => {
  req.requestId = Math.random().toString(36).substr(2, 9);
  res.setHeader('X-Request-ID', req.requestId);
  
  // Override logger methods to include request ID
  req.logger = {
    error: (message, meta = {}) => logger.error(`[${req.requestId}] ${message}`, meta),
    warn: (message, meta = {}) => logger.warn(`[${req.requestId}] ${message}`, meta),
    info: (message, meta = {}) => logger.info(`[${req.requestId}] ${message}`, meta),
    debug: (message, meta = {}) => logger.debug(`[${req.requestId}] ${message}`, meta),
  };
  
  next();
};

// Log HTTP requests
logger.logRequest = (req, res, next) => {
  const start = Date.now();
  
  res.on('finish', () => {
    const duration = Date.now() - start;
    const message = `${req.method} ${req.originalUrl} ${res.statusCode} ${duration}ms`;
    
    if (res.statusCode >= 400) {
      logger.warn(message, {
        method: req.method,
        url: req.originalUrl,
        statusCode: res.statusCode,
        duration,
        userAgent: req.get('User-Agent'),
        ip: req.ip,
        requestId: req.requestId
      });
    } else {
      logger.info(message, {
        method: req.method,
        url: req.originalUrl,
        statusCode: res.statusCode,
        duration,
        requestId: req.requestId
      });
    }
  });
  
  next();
};

module.exports = logger;
