#!/usr/bin/env bash
# Idempotent deploy script for a single EC2 instance (use Launch Template + ASG for production)
# Usage: ssh ec2-user@<host> 'bash -s' < backend/deploy-to-ec2.sh
set -euo pipefail

APP_ROOT="/opt/ecommerce-app"
BACKEND_DIR="$APP_ROOT/backend"
LOG_DIR="$APP_ROOT/logs"

# Packages
if command -v dnf >/dev/null 2>&1; then
  sudo dnf -y update
  sudo dnf -y install unzip nodejs
elif command -v yum >/dev/null 2>&1; then
  sudo yum -y update
  # Node 18 via nodesource if needed
  if ! command -v node >/dev/null 2>&1; then
    curl -fsSL https://rpm.nodesource.com/setup_18.x | sudo bash -
    sudo yum -y install nodejs
  fi
  sudo yum -y install unzip
elif command -v apt-get >/dev/null 2>&1; then
  sudo apt-get update -y
  sudo apt-get install -y unzip nodejs npm
fi

# Create paths
sudo mkdir -p "$BACKEND_DIR" "$LOG_DIR"
sudo chown -R ec2-user:ec2-user "$APP_ROOT"

# Copy current directory contents to target (assumes you rsync/scp your backend folder first)
rsync -a --delete ./ "$BACKEND_DIR"/

# Install dependencies (production only)
cd "$BACKEND_DIR"
if [ -f package-lock.json ]; then
  npm ci --omit=dev
else
  npm install --omit=dev
fi

# Put env file in place if you provided one
if [ -f ".env.production" ] && [ ! -f ".env" ]; then
  cp .env.production .env
fi
sudo chown ec2-user:ec2-user .env || true
sudo chmod 600 .env || true

# Install/enable systemd service
sudo tee /etc/systemd/system/ecommerce-backend.service >/dev/null <<'EOF'
[Unit]
Description=E-commerce Backend API
After=network.target

[Service]
Type=simple
User=ec2-user
Group=ec2-user
WorkingDirectory=/opt/ecommerce-app/backend
EnvironmentFile=/opt/ecommerce-app/backend/.env
ExecStart=/usr/bin/node server.js
Restart=always
RestartSec=5
LimitNOFILE=65536
StandardOutput=journal
StandardError=journal
SyslogIdentifier=ecommerce-backend

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable ecommerce-backend
sudo systemctl restart ecommerce-backend

echo "Deploy complete. Check status with: sudo systemctl status ecommerce-backend"
