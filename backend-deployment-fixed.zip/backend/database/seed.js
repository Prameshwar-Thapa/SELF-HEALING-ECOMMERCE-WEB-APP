const bcrypt = require('bcryptjs');
const { executeQuery, testConnection } = require('../config/database');

async function seedDatabase() {
  console.log('🌱 Starting database seeding...');
  
  // Test connection first
  const connected = await testConnection();
  if (!connected) {
    console.error('❌ Cannot connect to database. Please check your configuration.');
    process.exit(1);
  }

  try {
    // Clear existing data (optional - comment out if you want to keep existing data)
    console.log('Clearing existing data...');
    await executeQuery('DELETE FROM order_items');
    await executeQuery('DELETE FROM orders');
    await executeQuery('DELETE FROM cart_items');
    await executeQuery('DELETE FROM products');
    await executeQuery('DELETE FROM categories');
    await executeQuery('DELETE FROM users');

    // Reset auto increment
    await executeQuery('ALTER TABLE users AUTO_INCREMENT = 1');
    await executeQuery('ALTER TABLE categories AUTO_INCREMENT = 1');
    await executeQuery('ALTER TABLE products AUTO_INCREMENT = 1');

    // Seed users
    console.log('Seeding users...');
    const hashedAdminPassword = await bcrypt.hash('admin123', 10);
    const hashedCustomerPassword = await bcrypt.hash('customer123', 10);
    
    await executeQuery(`
      INSERT INTO users (email, password, first_name, last_name, role) VALUES
      ('admin@example.com', ?, 'Admin', 'User', 'admin'),
      ('customer@example.com', ?, 'John', 'Doe', 'customer'),
      ('jane@example.com', ?, 'Jane', 'Smith', 'customer')
    `, [hashedAdminPassword, hashedCustomerPassword, hashedCustomerPassword]);

    // Seed categories
    console.log('Seeding categories...');
    await executeQuery(`
      INSERT INTO categories (name, description, image_url) VALUES
      ('Electronics', 'Latest electronic gadgets and devices', 'https://images.unsplash.com/photo-1498049794561-7780e7231661?w=400'),
      ('Clothing', 'Fashion and apparel for all occasions', 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=400'),
      ('Books', 'Wide selection of books and literature', 'https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=400'),
      ('Home & Garden', 'Everything for your home and garden', 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=400'),
      ('Sports', 'Sports equipment and fitness gear', 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=400')
    `);

    // Seed products
    console.log('Seeding products...');
    await executeQuery(`
      INSERT INTO products (name, description, price, category_id, image_url, stock_quantity) VALUES
      -- Electronics
      ('Smartphone Pro Max', 'Latest flagship smartphone with advanced features', 999.99, 1, 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=400', 50),
      ('Wireless Headphones', 'Premium noise-cancelling wireless headphones', 299.99, 1, 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400', 75),
      ('Laptop Ultra', 'High-performance laptop for professionals', 1299.99, 1, 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=400', 30),
      ('Smart Watch', 'Fitness tracking smartwatch with health monitoring', 399.99, 1, 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400', 60),
      
      -- Clothing
      ('Classic T-Shirt', 'Comfortable cotton t-shirt in various colors', 29.99, 2, 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=400', 100),
      ('Denim Jeans', 'Premium quality denim jeans with perfect fit', 79.99, 2, 'https://images.unsplash.com/photo-1542272604-787c3835535d?w=400', 80),
      ('Winter Jacket', 'Warm and stylish winter jacket for cold weather', 149.99, 2, 'https://images.unsplash.com/photo-1544966503-7cc5ac882d5f?w=400', 45),
      ('Running Shoes', 'Comfortable running shoes for daily exercise', 119.99, 2, 'https://images.unsplash.com/photo-1549298916-b41d501d3772?w=400', 65),
      
      -- Books
      ('Programming Guide', 'Complete guide to modern programming languages', 49.99, 3, 'https://images.unsplash.com/photo-1532012197267-da84d127e765?w=400', 40),
      ('Fiction Novel', 'Bestselling fiction novel by renowned author', 19.99, 3, 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=400', 55),
      ('Cookbook Deluxe', 'Professional cookbook with 500+ recipes', 39.99, 3, 'https://images.unsplash.com/photo-1589829085413-56de8ae18c73?w=400', 35),
      
      -- Home & Garden
      ('Coffee Maker', 'Automatic coffee maker with programmable features', 89.99, 4, 'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=400', 25),
      ('Garden Tools Set', 'Complete set of essential garden tools', 69.99, 4, 'https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=400', 40),
      ('Decorative Lamp', 'Modern decorative lamp for living room', 129.99, 4, 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400', 30),
      
      -- Sports
      ('Yoga Mat', 'Premium non-slip yoga mat for all exercises', 39.99, 5, 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=400', 70),
      ('Basketball', 'Official size basketball for indoor/outdoor play', 24.99, 5, 'https://images.unsplash.com/photo-1546519638-68e109498ffc?w=400', 85),
      ('Fitness Tracker', 'Advanced fitness tracker with heart rate monitor', 199.99, 5, 'https://images.unsplash.com/photo-1575311373937-040b8e1fd5b6?w=400', 50)
    `);

    console.log('✅ Database seeding completed successfully!');
    console.log('');
    console.log('📋 Default accounts created:');
    console.log('   Admin: admin@example.com / admin123');
    console.log('   Customer: customer@example.com / customer123');
    console.log('');
    console.log('📦 Sample data:');
    console.log('   - 5 categories');
    console.log('   - 16 products');
    console.log('   - 3 users');

  } catch (error) {
    console.error('❌ Seeding failed:', error.message);
    process.exit(1);
  }
}

// Run seeding if this file is executed directly
if (require.main === module) {
  seedDatabase().then(() => {
    process.exit(0);
  });
}

module.exports = { seedDatabase };
